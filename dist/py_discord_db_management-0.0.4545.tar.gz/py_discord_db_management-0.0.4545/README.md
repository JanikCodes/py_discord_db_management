# Python Discord Database Management Package

This is a work in progress..

# Todo
- take column attributes into account ( Auto increment, default values, . . )
- add util methodes to further change the framework, like manually setting a custom default value, making columns hidden in modal, . .
- allow viewing next modal/previous & applying changes to previous data in those modals